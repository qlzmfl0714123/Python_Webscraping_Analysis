cities = ["서울","부산","인천", \
        "대구","대전","광주","울산","수원"]
print(cities[0:6])
print(cities[:])
print(cities[-50:50])
print(cities[::2], " AND ", cities[::-1])
