colors = ["red", "blue", "green","aa"]
print(colors[0])
print(colors[2])
print(len(colors))
colors.sort(key=lambda tup: tup[1])
print(colors)

numbers = ['ba','cg','ar']
print(numbers)
numbers.sort(key=lambda tup: tup[1])
print(numbers)

a = [3, 6, 8, 2, 78, 1, 23, 45, 9]
a.sort()
print(a)

colors = ["red", "blue", "green","aa"]
colors.sort()
print(colors)