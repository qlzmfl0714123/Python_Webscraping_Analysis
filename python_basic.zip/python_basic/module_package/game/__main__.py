from mycode.module_package.game.graphic.render import render_test
from mycode.module_package.game.sound.echo  import echo_test

if __name__ == "__main__":
    render_test()
    echo_test()
