def render_test():
    print("render")
