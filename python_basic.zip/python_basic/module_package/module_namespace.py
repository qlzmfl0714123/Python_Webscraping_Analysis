# import fah_converter as fah
# print(fah.covert_c_to_f(41.6))

# from fah_converter import covert_c_to_f
# print(covert_c_to_f(41.6))

from fah_converter import *
print(covert_c_to_f(41.6))
print(test_value)
