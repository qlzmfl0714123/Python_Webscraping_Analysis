from mycode.module_package.package.game.graphic.render import render_test()

render_test()

from .render import render_test()
from ..sound.echo import echo_test()


render_test()
echo_test()