# render.py
def render_test():
    print ("render")